<script>

    function getLgaByStateId() {
        var url = '/Lga/get/' + $('#state').val();
        $.ajax({
            url: url,
            success: function (response) {
                var query = response;
                $('#lga')
                        .find('option')
                        .remove()
                        .end()
                        .append('<option value="">Select Local Gvt.</option>')
                        .val('');
                $.each(JSON.parse(query), function(key, value) {
                    $('#lga')
                            .append($("<option></option>")
                                    .attr("value",value['local_id'])
                                    .text(value['local_name']));
                });
            },
            error: function (xhr) {
                console.log('error');
            }
        });


    }

    $( "#state" ).change(function() {
       getLgaByStateId();
    });


</script>
