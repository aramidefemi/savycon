<!--footer section start-->

<footer style="margin-top:40px;">
    <div class="footer-bottom text-center">
        <div class="container">
            <div class="foo-grids">
                <div class="col-md-4 footer-grid text-left">
                    <h4 class="footer-head">Who We Are</h4>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                    <h4 CLASS="text-muted">Subscribe to Newsletter</h4>
                    <hr>
                    <form action="{{ url("subscribe-newsletter") }}" method="post">
                        {{ csrf_field() }}
                        <div class="input-group">
                            <input type="text" name="email" class="form-control" placeholder="Your email">
                            <div class="input-group-btn">
                                <button class="btn btn-danger" type="submit" style="padding: 7px;;"><span class="fa fa-paper-plane"></span></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-4 footer-grid text-left">
                    <h4 class="footer-head">Information</h4>
                    <ul>
                        <li><a href="{{ url("#") }}">Locations Map</a></li>
                        <li><a href="{{ url("#") }}">Terms of Use</a></li>
                        <li><a href="{{ url("#") }}">Popular searches</a></li>
                    </ul>
                </div>
                <div class="col-md-4 footer-grid text-left">
                    <h4 class="footer-head">Contact Us</h4>
                    <address>
                        <ul class="location">
                            <li><span class="glyphicon glyphicon-map-marker"></span></li>
                            <li>CENTER FOR FINANCIAL ASSISTANCE TO DEPOSED NIGERIAN ROYALTY</li>
                            <div class="clearfix"></div>
                        </ul>
                        <ul class="location">
                            <li><span class="glyphicon glyphicon-earphone"></span></li>
                            <li>+0 561 111 235</li>
                            <div class="clearfix"></div>
                        </ul>
                        <ul class="location">
                            <li><span class="glyphicon glyphicon-envelope"></span></li>
                            <li><a href="mailto:info@example.com">mail@example.com</a></li>
                            <div class="clearfix"></div>
                        </ul>
                    </address>
                </div>
                <div class="clearfix"></div>
            </div>

            <div class="footer-logo">
                <a href="{{url('/') }}"><span>J</span>AG</a>
            </div>
            <div class="col-md-8 col-md-offset-2">
               <div class="col-md-12">
                   <a href="#"><img src="{{ url("assets/images/1.png") }}" alt=""></a>
                   <a href="#"><img src="{{ url("assets/images/2.png") }}" alt=""></a>
               </div>
            </div>
            <div class="clearfix"></div>
            <div class="footer-social-icons">
                <ul>
                    <li><a class="facebook" href="#"><span>Facebook</span></a></li>
                    <li><a class="twitter" href="#"><span>Twitter</span></a></li>
                    <li><a class="flickr" href="#"><span>Flickr</span></a></li>
                    <li><a class="googleplus" href="#"><span>Google+</span></a></li>
                    <li><a class="dribbble" href="#"><span>Dribbble</span></a></li>
                </ul>
            </div>
            <div class="copyrights">
                <p> &copy; {{ date('Y') }} JAG. All Rights Reserved </p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</footer>
<!--footer section end-->

lorem