<script>

//    function getAdvertSingle() {
//        var url = '/single/ad/' + $('#advrt').val();
//        console.log(ok);
//        $.ajax({
//            url: url,
//            success: function (response) {
//                var query = response;
//               console.log(query);
//            },
//            error: function (xhr) {
//                console.log('error');
//            }
//        });
//
//
//    }
    $('#advert').onclick(function(){
        preventdefault();
       alert('ok');
    });
</script>