<style>
    @media(max-width: 420px){
        .mobile{
            position: relative;
            top: -16px;
            right: -40px;
        }
    }
</style>
<div class="header">
    <div class="container">
        <div class="logo">
            <a href="{{ url("/") }}"><span>J</span>AG</a>
        </div>
        <div class="header-right">
            <div class="col-xs-12">
                @if(auth()->user())
                    <a class="account" href="{{ url("dashboard") }}">My Account</a>
                    <span class="dropdown nav-drop">
                    <button class="btn mobile" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                       <span class="">
                            <i class="fa fa-user"></i> {{ auth()->user()->email }}
                           <span class="caret"></span>
                       </span>

                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <li><a href="#">Action</a></li>
                        <li><a href="#">Account Settings</a></li>
                        <li><a href="{{ url("user/advert") }}">My Advert</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="{{ url("auth/logout") }}">Sign Out</a></li>
                    </ul>
                </span>
                    @else
                    <a class="account" href="{{ url("auth/login") }}">Login</a>
                @endif
            </div>

        </div>
    </div>
</div>
{{--<div class="banner text-center">--}}
    {{--<div class="container">--}}
        {{--<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with Resale</h1>--}}
        {{--<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>--}}
        {{--@if(auth()->user())--}}
            {{--<a href="{{ url("/new-advert") }}">Post Free Ad</a>--}}
        {{--@endif--}}
    {{--</div>--}}
{{--</div>--}}