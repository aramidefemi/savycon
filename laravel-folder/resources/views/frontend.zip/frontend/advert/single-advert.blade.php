@extends('frontend.layouts.master')

@section('content')
        <!--single-page-->
<div class="single-page main-grid-border">
    <div class="container">
        <ol class="breadcrumb" style="margin-bottom: 5px;">
            <li><a href="{{ url("/") }}">Home</a></li>
            <li class="active">{{ $product->title }}</li>
        </ol>
        <div class="product-desc">
            <div class="col-md-7 product-view">
                <h2>{{ $product->title }}</h2>
                <p> <i class="glyphicon glyphicon-map-marker"></i><a href="#">State: {{ $product->state }}</a>, <a href="#">city: </a>| Added  {{ $product->created_at->diffForHumans() }}</p>
                <div class="flexslider">
                    <ul class="slides">
                        @foreach($product->photos as $photo)
                            <li data-thumb="{{ url("assets/Product/" .$photo->filename) }}">
                                <img src="{{ url("assets/Product/" .$photo->filename) }}" />
                            </li>
                        @endforeach
                    </ul>
                </div>

                <!-- //FlexSlider -->
                <div class="product-details">
                    <p>{{ $product->title }}</p>
                    <p><strong>Summary</strong> :
                        {{ $product->description }}
                    </p>

                </div>
            </div>
            <div class="col-md-5 product-details-grid">
                <div class="item-price">
                    <div class="product-price">
                        <p class="p-price">Price</p>
                        <h3 class="rate">&#8358;{{ $product->price }}</h3>
                        <div class="clearfix"></div>
                    </div>
                    <div class="condition">
                        <p class="p-price">Type</p>
                        <h5 class="text-info" style="text-transform: capitalize">{{ $product->price_type }}</h5>
                        <div class="clearfix"></div>
                    </div>
                    <div class="itemtype">
                        <p class="p-price">Job Type</p>
                        <h4>{{ $product->category_name }}</h4>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="interested text-center bg-info">
                    <div class="row">
                        <h4>Interested in this Ad?<small> Contact the Seller!</small></h4>
                        <p class="col-md-"><i class="glyphicon glyphicon-earphone"></i>{{ $product->user->phone }}</p>
                        <p class="col-md-"><i class="glyphicon glyphicon-envelope"></i>{{ $product->user->email }}</p>
                    </div>

                </div>
                <div class="tips">
                    <h4>Safety Tips for Buyers</h4>
                    <ol>
                        <li><a href="#">Contrary to popular belief.</a></li>
                        <li><a href="#">Contrary to popular belief.</a></li>
                        <li><a href="#">Contrary to popular belief.</a></li>
                    </ol>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--//single-page-->
@endsection
@section('js-after')
    <script type="text/javascript" src="{{ url("assets/js/jquery.flexisel.js") }}"></script>
    <script defer src="{{ url("assets/js/jquery.flexslider.js") }}"></script>
    <script>
        // Can also be used with $(document).ready()
        $(window).load(function() {
            $('.flexslider').flexslider({
                animation: "slide",
                controlNav: "thumbnails"
            });
        });
    </script>
@endsection