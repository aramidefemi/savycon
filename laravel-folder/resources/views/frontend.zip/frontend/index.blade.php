@extends('frontend.layouts.master')

@section('content')
    <div class="banner text-center">
        <div class="container">
            <div style="margin-top: 20px;">
                <h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with JAG</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                @if(auth()->user())
                    <a href="{{ url("/new-advert") }}">Post Free Ad</a>
                @endif
            </div>
            <div class="col-md-12" style="margin-top: 10px;">
                <form action="">
                    <div class="form-group">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="">
                                <div class="input-group input-group-lg">
                                    <input type="text" name="search" class="form-control input-lg" placeholder="Search for Freelancer e.g Automobile Repairer lagos" aria-describedby="basic-addon2">
                                    <span class="input-group-addon -lg" id="basic-addon2"><button class="btn btn-xs btn-danger"><i class="fa fa-search"></i></button></span>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- content-starts-here -->
    <div class="content">
        <div class="total-ads main-grid-border">
            <div class="container">
                <ol class="breadcrumb" style="margin-bottom: 5px;">
                    <li><a href="{{ url("/") }}">Home</a></li>
                </ol>
                <div class="ads-grid">
                    <div class="side-bar col-md-3">
                        <div class="featured-ads">
                            <h2 class="sear-head fer">Featured Ads</h2>
                            <hr>
                            @if($featuredAd->isEmpty())
                                <p class="alert alert-warning">something Awesome is Coming</p>
                            @else
                                @foreach($featuredAd as $ad)
                                    <a href="{{ url("#") }}" class="">
                                        <div class="featured-ad-left" style="margin-right:3%;">
                                            <img src="<?php echo explode(',',$ad->img_url)['0'] ?>" title="ad image" alt="" />
                                        </div>
                                        <div class="featured-ad-right">
                                            <h4 class="text-muted">{{ $ad->title }}</h4>
                                        </div>
                                        <div class="clearfix"></div>
                                    </a>
                                    <br>
                                    <p  style="padding: 0px; margin: 0px;;"><a href="{{ url("#") }}" class="btn btn-info btn-xs btn-block">Read More</a></p>
                                @endforeach
                            @endif
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="ads-display col-md-9">
                        <div class="wrapper">
                            <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                                <div id="myTabContent" class="tab-content" style="border: 1px solid transparent !important">
                                    <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
                                        <div>
                                            <div id="container">
                                                <div class="clearfix"></div>
                                                @if($adverts->isEmpty())
                                                    <p class="alert alert-waning">No FreeLancer Available</p>
                                                @else
                                                    <ul class="card" style="display: block; margin-bottom: 40px;">
                                                        <h4 class="text-muted" style="color:#fff; font-weight:500; padding: 10px; margin-top: 10px; background: #080808">Latest Buyer Request</h4>
                                                        <hr>
                                                        @foreach ($adverts->chunk(3) as $chunk)
                                                            <div class="row">
                                                                @foreach ($chunk as $advert)
                                                                    <div class="col-sm-6 col-md-4">
                                                                        <div class="thumbnail">
                                                                            <img src="{{ url("assets/Product/".$advert->photos->first()->filename) }}"  class="img-rounded img-responsive" alt="{{ url("assets/Product/".$advert->photos->first()->filename) }}" style="height: 178px;">
                                                                            <div class="caption text-center ">
                                                                                <h6 class="title">{{$advert->title }}</h6>
                                                                                <span class="adprice">&#8358;{{$advert->price }}</span>
                                                                                <p class="catpath">{{$advert->category_name }}</p>
                                                                                <span class="date"><strong>{{$advert->created_at->format('d:m:Y|h:i') }}</strong></span>
                                                                                <span class="cityname"><strong>City:</strong>{{$advert->state }}</span>
                                                                                <p>
                                                                                    <a href="{{ url("single/advert/$advert->id") }}" class="btn btn-info btn-block btn-xs" role="button">Get Info</a>
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </div>
                                            <div>
                                                {!! $adverts->render() !!}
                                            </div>
                                        </div>

                                        <div>
                                            <div id="container">
                                                <div class="clearfix"></div>
                                                @if($freelancers->isEmpty())
                                                    <p class="alert alert-waning">No FreeLancer Available</p>
                                                @else
                                                    <ul class="grid card" style="display: block">
                                                        <h4 class="text-muted" style="color:#fff; font-weight:500; padding: 10px; margin-top: 10px; background: #f90">Latest Freelancer</h4>
                                                        <hr>
                                                        @foreach ($freelancers->chunk(3) as $chunk)
                                                            <div class="">
                                                                @foreach ($chunk as $freelancer)
                                                                    <div class="col-sm-6 col-md-4">
                                                                        <div class="thumbnail">
                                                                            <img src="<?php echo $img = explode(',',$freelancer->img_url)['0'] ?>"  class="img-rounded img-responsive" alt="{{ url("assets/Product/".$advert->photos->first()->filename) }}" style="height: 178px;">
                                                                            <div class="caption text-center ">
                                                                                <h6 class="title">{{$freelancer->title }}</h6>
                                                                                <span class="adprice">&#8358;{{$freelancer->price }}</span>
                                                                                <p class="catpath">{{$freelancer->category_name }}</p>
                                                                                <span class="date"><strong>{{$freelancer->created_at->format('d:m:Y|h:i') }}</strong></span>
                                                                                <span class="cityname"><strong>City:</strong>{{$freelancer->state }}</span>
                                                                                <p>
                                                                                    <a href="{{ url("single/advert/$freelancer->id") }}" class="btn btn-info btn-block btn-xs" role="button">Get Info</a>
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </div>
                                            <div>
                                                {!! $freelancers->render() !!}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
@endsection
