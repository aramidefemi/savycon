@extends('backend.layouts.master')

@section('page-header')
    <h1>
        New Category
    </h1>
@endsection


@section('content')
    <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Create New Category</h3>
          <div class="box-tools pull-right">
              <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div><!-- /.box-header -->
        <div class="box-body">
            <form action="{{ url('admin/new/banner') }}" method="post" role="form" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="cat name"> Banner Images:</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" value="Add New Banner" class="btn btn-info">
                </div>
            </form>
        </div><!-- /.box-body -->
    </div><!--box box-success-->
@endsection