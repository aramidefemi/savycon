@extends('frontend.layouts.master')

@section('content')
    <style>
        body{
            background: #efefef;
        }
    </style>
    <div class="container">
        <div class="col-md-12 col-md-offset-0" style="margin-top: 20px;">
            <div class="panel panel-default card">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4 col-md-push-8" style="padding-top: 12px;">
                            <ul class="media-list card">
                                <li class="media">
                                    <div class="media-left" style="position: relative; top: 8px;">
                                        <i class="fa fa-user fa-3x"></i>
                                    </div><!--media-left-->

                                    <div class="media-body">
                                        <h4 class="media-heading">
                                            {{ auth()->user()->name }}<br/>
                                            <small>
                                                {{ auth()->user()->email }}<br/>
                                                Joined {{ auth()->user()->created_at->format('F jS, Y') }}
                                                <br>
                                                <strong>Member Type:</strong> <span  style="text-transform: capitalize">{{ auth()->user()->user_type ? auth()->user()->user_type : 'Nil' }}</span>
                                            </small>

                                        </h4>
                                        @permission('view-backend')
                                        <a href="{{ route("backend.dashboard") }}" class="btn btn-danger btn-xs">Administration Section</a>
                                        @endauth
                                    </div><!--media-body-->
                                </li><!--media-->
                            </ul><!--media-list-->

                            <div class="panel panel-default ">
                                <div class="panel-heading">
                                    <br>
                                    <h4>Feautured Ads</h4>
                                    <hr>
                                </div><!--panel-heading-->

                                <div class="panel-body ard">
                                    @if($featuredAd->isEmpty())
                                        <p class="alert alert-warning">something Awesome is Coming</p>
                                    @else
                                        @foreach($featuredAd as $ad)
                                            <div class="card" style="margin-bottom:9px;">
                                                <a href="{{ url("#") }}" class="">
                                                    <div class="featured-ad-left" style="margin-right:3%;">
                                                        <img src="<?php echo explode(',',$ad->img_url)['0'] ?>" title="ad image" alt="" />
                                                    </div>
                                                    <div class="featured-ad-right">
                                                        <h4 class="text-muted">{{ $ad->title }}</h4>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </a>
                                                <p  style="padding: 0px; margin: 0px;;"><a href="{{ url("#") }}" class="btn btn-info btn-xs btn-block">Read More</a></p>

                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                                <!--panel-body-->
                            </div><!--panel-->
                        </div><!--col-md-4-->

                        <div class="col-md-8 col-md-pull-4">
                            <div class="row">
                                @if(auth()->user()->user_type == 'freelance')
                                    <h4 class="text-muted" style="color:#fff; font-weight:500; padding: 10px; margin-top: 10px; background: #080808">Latest Buyer Request</h4>
                                @elseif(auth()->user()->user_type == 'buyer')
                                    <h4 class="text-muted" style="color:#fff; font-weight:500; padding: 10px; margin-top: 10px; background: #080808">Recent Freelancer</h4>
                                @endif
                                <hr>
                                @if($details->isEmpty())
                                    <p class="alert alert-warning">
                                        No Offer Available for Your Category
                                    </p>
                                @else
                                    <div class="cards">
                                        <div class="row">
                                            @foreach($details as $detail)
                                                <div class="col-sm-6 col-md-4">
                                                    <div class="thumbnail">
                                                        @if(auth()->user()->user_type == 'freelance')
                                                            <img src="{{ url("assets/Product/".$detail->photos->first()->filename) }}" class="img-rounded img-responsive" alt="{{ url("assets/Product/".$detail->photos->first()->filename) }}" style="height: 178px;;">
                                                        @elseif(auth()->user()->user_type == 'buyer')
                                                            <img src="{{ url("assets/Product/".$detail->photos->first()->filename) }}" class="img-rounded img-responsive" alt="{{ url("assets/Product/".$detail->photos->first()->filename) }}" style="height: 178px;;">
                                                        @endif
                                                        <div class="caption">
                                                            <h4 class="text-center text-danger text-muted">{{ $detail->title }}</h4>
                                                            <div class="text-info text-left bg-info" style="padding: 7px; font-weight: 600; border-radius: 5px; margin-top: 10px;">Category: {{ $detail->category_name }}
                                                                <br>
                                                                State: {{ $detail->state }}<br>
                                                                Price: {{ $detail->price }}
                                                                <br>Type: {{ $detail->price_type }}
                                                                <br>Created: {{ $detail->created_at->format('d:m:Y|h:i') }}
                                                            </div>
                                                        </div>

                                                        <p>
                                                            <a href="{{ url("") }}" class="btn btn-xs btn-danger btn-block" role="button">Get Details</a>
                                                        </p>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif
                            </div><!--row-->

                        </div><!--col-md-8-->

                    </div><!--row-->

                </div><!--panel body-->

            </div><!-- panel -->

        </div>
    </div>
@endsection