@extends('frontend.layouts.master')

@section('content')
    <div class="container" style="margin-bottom: 10px; margin-top: 5px;">
        <section >
            <div id="page-wrapper" class="sign-in-wrapper" style="">
                <div class="" >
                    <div class="col-md-10 col-md-offset-1 reg" style="background: #efefef; border: 1px solid transparent; margin-bottom:20px;">
                        <h4 class="lead text-center text-muted" style="padding: 10px; margin-top: 10px;">Register As Freelancer</h4>
                        <div class="row">
                            <div class="panel-body col-md-12">

                                <form action="{{ url("auth/register/freelance") }}" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <div class="col-md-6">
                                        <div class="col-md-12 card">
                                            <h4 class="text-muted" style="padding: 10px">Personal Details</h4>
                                            <hr>
                                            <div class="form-group">
                                                {!! Form::label('name', trans('validation.attributes.name'), ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('name', 'name', old('name'), ['class' => 'form-control', 'placeholder'=>'Enter your full name']) !!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('phone', 'Phone', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('text', 'phone', old('phone'), ['class' => 'form-control', 'placeholder'=>'Enter your Phone Number']) !!}
                                                </div>
                                            </div>
                                            {{--                                {!! Form::input('hidden', 'user_type',  ['class' => 'form-control', 'value'=>'freelance']) !!}--}}
                                            <input type="hidden" name="user_type" value="freelance">
                                            <div class="form-group">
                                                {!! Form::label('email', trans('validation.attributes.email'), ['class' => 'col-md-2 contrsol-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('email', 'email', old('email'), ['class' => 'form-control', 'placeholder'=>'Enter your email']) !!}
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                {!! Form::label('password', trans('validation.attributes.password'), ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('password', 'password', null, ['class' => 'form-control','placeholder'=>'Enter Password']) !!}
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                {!! Form::label('password_confirmation', trans('validation.attributes.password_confirmation'), ['class' => 'col-md-12 controsl-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('password', 'password_confirmation', null, ['class' => 'form-control', 'placeholder'=>'Confirm Password']) !!}
                                                </div>
                                            </div>

                                        </div>

                                        <div class="col-md-12 card" style="margin-top: 10px;;">
                                            <h4 class="text-muted" style="padding: 10px">Store Images</h4>
                                            <hr>
                                            <div class="form-group">
                                                {!! Form::label('name', 'Upload Store Images', ['class' => 'col-md-6 codntrol-label']) !!}
                                                <div class="col-md-12">
                                                    <input type="file" id="exampleInputFile" name="photos[]" multiple />
                                                    <p>Maximum number of image(s) 7</p>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="col-md-12 card">
                                            <h4 class="text-muted" style="padding: 10px">Store Details</h4>
                                            <hr>
                                            <div class="form-group">
                                                {!! Form::label('Title', 'Title', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('text', 'title', old('title'), ['class' => 'form-control', 'placeholder'=>'Enter Freelance Title']) !!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('Url', 'Url', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('text', 'url', old('url'), ['class' => 'form-control', 'placeholder'=>'Enter your Site address, Youtube Address (Optional)']) !!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('category', 'Job Category', ['class' => 'col-md-12 control-ldabel']) !!}
                                                <div class="col-md-12">
                                                    <select name="category" id="category" class="form-control">
                                                        <option value="">Select your Job Category</option>
                                                        @foreach($categories as $category)
                                                            <option value="{{ $category->name }}">{{ $category->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('state', 'State', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    <select name="state" id="state" class="form-control">
                                                        <option value="">Select your State</option>
                                                        @foreach($states as $state)
                                                            <option value="{{ $state->name }}">{{ $state->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                {!! Form::label('lga', 'Area', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    <select name="lga" id="lga" class="form-control">
                                                        <option value="">Select Local Gvt.</option>

                                                    </select>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('price', 'Price', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('text', 'price', old('tag'), ['class' => 'form-control']) !!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('price_type', 'Price Type', ['class' => 'col-md-3 contrsol-label']) !!}
                                                <div class="col-md-12">
                                                    <select name="price_type" id="price_type" class="form-control">
                                                        <option value="">Select Price Type</option>
                                                        <option value="Negotiable">Negotiable</option>
                                                        <option value="Contact For Price">Contact For Price</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('tag', 'Tag', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    {!! Form::input('text', 'tag', old('tag'), ['class' => 'form-control', 'placeholder'=>'Enter your Freelance Tag']) !!}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                {!! Form::label('desc', 'Description', ['class' => 'col-md-1 control-label']) !!}
                                                <div class="col-md-12">
                                                    <textarea name="description" id="description"  class="form-control" placeholder='Enter your Freelance Description'></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-md-8 col-md-offset-2">
                                                    {!! Form::submit(trans('labels.register_button'), ['class' => 'account btn btn-info btn-block']) !!}
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                {!! Form::close() !!}

                            </div><!-- panel body -->
                        </div>

                    </div>
                </div>
            </div>
        </section>

    </div>
@endsection

@section('ajax')
    @include('frontend.includes.ajax')
@endsection

