@extends('frontend.layouts.master')

@section('content')
    <div class="col-md-12">
        <form action="">
            <div class="form-group">
                <div class="col-md-10 col-md-offset-1">
                    <div class="well">
                        <div class="input-group input-group-lg">
                            <input type="text" name="search" class="form-control input-lg" placeholder="Search by name, City" aria-describedby="basic-addon2">
                            <span class="input-group-addon" id="basic-addon2"><button class="btn btn-xs btn-danger"><i class="fa fa-search"></i></button></span>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>
    <div class="total-ads main-grid-border">
        <div class="container">
            <ol class="breadcrumb" style="margin-bottom: 5px;">
                <li><a href="{{ url("/") }}">Home</a></li>
                <li><a href="{{ url("user/advert") }}">My Advert</a></li>
            </ol>
            <div class="ads-grid">
                <div class="side-bar col-md-3">
                    <div class="featured-ads">
                        <h2 class="sear-head fer">Featured Ads</h2>
                        <div class="featured-ad">
                            <a href="single.html">
                                <div class="featured-ad-left">
                                    <img src="images/f1.jpg" title="ad image" alt="" />
                                </div>
                                <div class="featured-ad-right">
                                    <h4>Lorem Ipsum is simply dummy text of the printing industry</h4>
                                    <p>$ 450</p>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div class="featured-ad">
                            <a href="single.html">
                                <div class="featured-ad-left">
                                    <img src="images/f2.jpg" title="ad image" alt="" />
                                </div>
                                <div class="featured-ad-right">
                                    <h4>Lorem Ipsum is simply dummy text of the printing industry</h4>
                                    <p>$ 380</p>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div class="featured-ad">
                            <a href="single.html">
                                <div class="featured-ad-left">
                                    <img src="images/f3.jpg" title="ad image" alt="" />
                                </div>
                                <div class="featured-ad-right">
                                    <h4>Lorem Ipsum is simply dummy text of the printing industry</h4>
                                    <p>$ 560</p>
                                </div>
                                <div class="clearfix"></div>
                            </a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="ads-display col-md-9">
                    <div class="wrapper">
                        <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                            <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
                                        <span class="text">My Adverts</span>
                                    </a>
                                </li>
                            </ul>
                            <div id="myTabContent" class="tab-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
                                    <div>
                                        <div id="container">
                                            <div class="clearfix"></div>
                                            @if($adverts->isEmpty())
                                                <p class="alert alert-warning text-center text-muted">No advert Created Yet</p>
                                            @else
                                                <ul class="list">
                                                    @foreach($adverts as $advert)
                                                        <a href="{{ url("single/advert/$advert->id") }}">
                                                            <li>
                                                                <img src="{{ url("assets/Product/".$advert->photos->first()->filename) }}" title="" alt="" />
                                                                <section class="list-left">
                                                                    <h5 class="title">{{$advert->title }}</h5>
                                                                    <span class="adprice">&#8358;{{$advert->price }}</span>
                                                                    <p class="catpath">{{$advert->category }}</p>
                                                                </section>
                                                                <section class="list-right">
                                                                    <span class="date">{{$advert->created_at->format('y M D') }}</span>
                                                                    <span class="cityname">{{$advert->state }}</span>
                                                                </section>
                                                                <div class="clearfix"></div>
                                                            </li>
                                                        </a>
                                                    @endforeach
                                                </ul>
                                            @endif
                                            <div>
                                                {!! $adverts->render() !!}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
@endsection
