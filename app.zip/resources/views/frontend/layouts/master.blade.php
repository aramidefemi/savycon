<!DOCTYPE html>
<html lang="en">

<head>
    <title>SavyCon-Get your Job/work done, A place to meet professional near you.</title>
    <link rel="stylesheet" href="{{ url("assets/css/bootstrap.min.css") }}">
    <link rel="stylesheet" href="{{ url("assets/css/bootstrap-select.css") }}">
    <link href="{{ url("assets/css/style.css") }}" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="{{ url("assets/css/flexslider.css") }}" type="text/css" media="screen" />
    <link rel="stylesheet" href="{{ url("assets/css/font-awesome.min.css") }}" />
    <link href="{{ url("assets/css/jquery.uls.css") }}" rel="stylesheet"/>
    <link href="{{ url("assets/css/jquery.uls.grid.css") }}" rel="stylesheet"/>
    <link href="{{ url("assets/css/jquery.uls.lcd.css") }}" rel="stylesheet"/>
    <!-- for-mobile-apps -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //for-mobile-apps -->
    <!--fonts-->
    <link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <!--//fonts-->
    <style>
       .nav-drop{
            position: relative;
            top: 20px;
            left: 3px;
        }
        .card{
            box-shadow: 0px 0px 4px rgba(110,110,110, 0.24);
            padding: 10px;
            background: #fff;
        }
        .card h4{
            color: #f90;
        }
    </style>
</head>

<body>
<div  class="body-wrapper theme-clearfix">
    @include('frontend.includes.nav')

    <div class="">
        @include('includes.partials.messages')
        @yield('content')
        @include('frontend.includes.footer')
    </div><!-- container -->
</div><!--#app-->
@include('frontend.includes.home-modal')
        <!-- Scripts -->
<!-- js -->
<script type="text/javascript" src="{{ url("assets/js/jquery.min.js") }}"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="{{ url("assets/js/bootstrap.min.js") }}"></script>
<script src="{{ url("assets/js/bootstrap-select.js") }}"></script>
<script>
    $(document).ready(function () {
        var mySelect = $('#first-disabled2');

        $('#special').on('click', function () {
            mySelect.find('option:selected').prop('disabled', true);
            mySelect.selectpicker('refresh');
        });

        $('#special2').on('click', function () {
            mySelect.find('option:disabled').prop('disabled', false);
            mySelect.selectpicker('refresh');
        });

        $('#basic2').selectpicker({
            liveSearch: true,
            maxOptions: 1
        });
    });
</script>
<script type="text/javascript" src="{{ url("assets/js/jquery.leanModal.min.js") }}"></script>
<!-- Source -->
<script src="{{ url("assets/js/jquery.uls.data.js") }}"></script>
<script src="{{ url("assets/js/jquery.uls.data.utils.js") }}"></script>
<script src="{{ url("assets/js/jquery.uls.lcd.js") }}"></script>
<script src="{{ url("assets/js/jquery.uls.languagefilter.js") }}"></script>
<script src="{{ url("assets/js/jquery.uls.regionfilter.js") }}"></script>
<script src="{{ url("assets/js/jquery.uls.core.js") }}"></script>
<script>
    $( document ).ready( function() {
        $( '.uls-trigger' ).uls( {
            onSelect : function( language ) {
                var languageName = $.uls.data.getAutonym( language );
                $( '.uls-trigger' ).text( languageName );
            },
            quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
        } );
    } );
</script>
<script type="text/javascript">
    $(window).load(function() {
        $("#flexiselDemo3").flexisel({
            visibleItems:1,
            animationSpeed: 1000,
            autoPlay: true,
            autoPlaySpeed: 5000,
            pauseOnHover: true,
            enableResponsiveBreakpoints: true,
            responsiveBreakpoints: {
                portrait: {
                    changePoint:480,
                    visibleItems:1
                },
                landscape: {
                    changePoint:640,
                    visibleItems:1
                },
                tablet: {
                    changePoint:768,
                    visibleItems:1
                }
            }
        });

    });
</script>
@yield('js-after')

@yield('ajax')
</body>
</html>