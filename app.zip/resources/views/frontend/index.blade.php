@extends('frontend.layouts.master')

@section('content')
    <style>
        @media(max-width: 420px){
            .to{
                font-size: 9px !important;
            }
        }
        
        .card h4{
            color:#000 !important;
        }
    </style>
    <div class="banner text-center hidden-xs" style="	background:url('assets/images/savvy-gif.gif') no-repeat 0px 0px; !important">
        <div class="container">
            <div style="margin-top: 20px;">
                <!--<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with SavyCon</h1>-->
            </div>
            <div class="col-md-12" style="margin-top: 250px;">
                <form action="{{ url("search/results") }}" method="GET" role="form">
                    <div class="input-group col-md-12">
                        <div class="col-md-1s" style="margin-top: 40px;">
                            <form action="{{ url("search/results") }}" method="GET" role="form">
                                <div class="input-group col-md-12">
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" name="q" class="form-control to" placeholder="Automobile Mechanic Repairer">
                                    </div>
                                    <div class="input-group col-md-2 col-xs-5">
                                        <select name="category" id="category" class="form-control to">
                                            <option value="">State</option>
                                            @foreach($categories as $category)
                                                <option value="{{ $category->name }}">{{ $category->name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="input-group-btn">
                                            <button class="btn btn-danger" type="submit"><span class="fa fa-search"></span></button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
     <div class="banner text-center visible-xs" style="	background:url('assets/images/savvy-mobile.gif') no-repeat 0px 0px; width: 100% !important;
    -webkit-background-size: cover !important;
    background-size: cover;
    background-position: center center;
    max-width: 100%;">
        <div class="container">
            <div style="margin-top: 20px;">
                <!--<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with SavyCon</h1>-->
            </div>
            <div class="col-md-12" style="margin-top: 250px;">
                <form action="{{ url("search/results") }}" method="GET" role="form">
                    <div class="input-group col-md-12">
                        <div class="col-md-1s" style="margin-top: 40px;">
                            <form action="{{ url("search/results") }}" method="GET" role="form">
                                <div class="input-group col-md-12">
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" name="q" class="form-control to" placeholder="Automobile Mechanic Repairer">
                                    </div>
                                    <div class="input-group col-md-2 col-xs-5">
                                        <select name="category" id="category" class="form-control to">
                                            <option value="">State</option>
                                            @foreach($categories as $category)
                                                <option value="{{ $category->name }}">{{ $category->name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="input-group-btn">
                                            <button class="btn btn-danger" type="submit"><span class="fa fa-search"></span></button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
    
    <!-- content-starts-here -->
    <div class="content">
        <div class="total-ads main-grid-border">
            <div class="container">
                <div class="ads-grids">
                    <div class="side-bar col-md-3">
                        <div class="col-lg-12">
                            <h2 class="sear-head fer">Featured Ads</h2>
                            <hr>
                            @if($featuredAd->isEmpty())
                                <p class="alert alert-warning">something Awesome is Coming</p>
                            @else
                                @foreach($featuredAd as $ad)
                                    <div class="card" style="margin-bottom: 20px;;">
                                        <a href="{{ url("http://".$ad->url) }}" class="">
                                            <div class="featured-ad-left" style="margin-right:3%;">
                                                <img src="<?php echo url(explode(',',$ad->img_url)['0']) ?>" title="ad image" alt="" />
                                            </div>
                                            <div class="featured-ad-right">
                                                <h4 class="text-muted">{{ $ad->title }}</h4>
                                            </div>
                                            <div class="clearfix"></div>
                                        </a>
                                        <br>
                                        <p  style="padding: 0px; margin: 0px;"><a href="{{ url("http://".$ad->url) }}" target="_blank" class="btn btn-info btn-xs btn-block">Read More</a></p>
                                    </div>
                                @endforeach
                            @endif
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="ads-display col-md-9">
                        <div class="wrapper">
                            <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                                <div id="myTabContesnt" class="tab-scontent" style="border: 1px solid transparent !important">
                                    <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
                                        <div>
                                            <div id="container">
                                                <div class="clearfix"></div>
                                                @if($adverts->isEmpty())
                                                    <p class="alert alert-waning">No FreeLancer Available</p>
                                                @else
                                                    <ul class="card" style="display: block; margin-bottom: 40px;">
                                                        <h4 class="text-muted" style="color:#fff !important; font-weight:500; padding: 10px; margin-top: 10px; background: #0fa68c">Latest Buyer Request</h4>
                                                        <hr>
                                                        @foreach ($adverts->chunk(2) as $chunk)
                                                            <div class="row">
                                                                @foreach ($chunk as $advert)
                                                                    <div class="col-sm-6 col-md-6 col-xs-6">
                                                                        <div class="thumbnail"> @if($advert->photos->first()->filename == "")
                                            <p>No Image</p>
                                        @else
                                                             <img src="{{ url("assets/Product/".$advert->photos->first()->filename) }}"  class="img-rounded img-responsive" alt="{{ url("assets/Product/".$advert->photos->first()->filename) }}" style="height: 105px;">
                                        @endif
                                                                            <div class="caption text-center ">
                                                                                <h6 class="title">{{$advert->title }}</h6>
                                                                                <span class="adprice">&#8358;{{$advert->price }}</span>
                                                                                <p class="catpath">{{$advert->category_name }}</p>
                                                                                <span class="date hidden-xs"><strong>{{$advert->created_at->format('d:m:Y|h:i') }}</strong></span>
                                                                                <span class="date visible-xs" style="font-size:9px"><strong>{{$advert->created_at->format('d:m:Y|h:i') }}</strong></span>
                                                                                <span class="cityname hidden-xs"><strong>State:</strong>{{$advert->state }} {{$advert->lga }}</span>
                                                                                <span class="cityname visible-xs" style="font-size:9px;"><strong>State:</strong>{{$advert->state }} {{$advert->lga }}</span>
                                                                                <p>
                                                                                    <a href="{{ url("single/advert/$advert->id") }}" class="btn btn-info btn-block btn-xs" role="button">Get Info</a>
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </div>
                                            <div>
                                                {!! $adverts->render() !!}
                                            </div>
                                        </div>

                                        <div>
                                            <div id="constainer">
                                                <div class="clearfix"></div>
                                                @if($freelancers->isEmpty())
                                                    <p class="alert alert-waning">No FreeLancer Available</p>
                                                @else
                                                    <ul class="card" style="display: block">
                                                        <h4 class="text-muted" style="color:#fff !important; font-weight:500; padding: 10px; margin-top: 10px; background: #f3c500">Latest Freelancer</h4>
                                                        <hr>
                                                        @foreach ($freelancers->chunk(2) as $chunk)
                                                            <div class="row">
                                                                @foreach ($chunk as $freelancer)
                                                                    <div class="col-sm-6 col-md-6 col-xs-6">
                                                                        <div class="thumbnail">
                                                                            <img src="<?php echo $img = explode(',',$freelancer->img_url)['0'] ?>"  class="img-rounded img-responsive" alt="images" style="width:135px; height: 105px;">
                                                                            <div class="caption text-center ">
                                                                                <h6 class="title">{{$freelancer->title }}</h6>
                                                                                <span class="adprice">&#8358;{{$freelancer->price }}</span>
                                                                                <p class="catpath">{{$freelancer->category_name }}</p>
                                                                                <span class="date hidden-xs"><strong>{{$freelancer->created_at->format('d:m:Y|h:i') }}</strong></span>
                                                                                <span class="date visible-xs" style="font-size:9px"><strong>{{$freelancer->created_at->format('d:m:Y|h:i') }}</strong></span>
                                                                                <span class="cityname hidden-xs"><strong>State:</strong>{{$freelancer->user->state }} {{ $freelancer->user->lga }}</span>
                                                                                <span class="cityname visible-xs" style="font-size:9px"><strong>State:</strong>{{$freelancer->user->state }} {{ $freelancer->user->lga }}</span>
                                                                                <p>
                                                                                    <a href="{{ url("single/freelance/$freelancer->id") }}" class="btn btn-info btn-block btn-xs" role="button">Get Info</a>
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </div>
                                            <div>
                                                {!! $freelancers->render() !!}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
    @include('frontend.includes.home-modal')
@endsection
