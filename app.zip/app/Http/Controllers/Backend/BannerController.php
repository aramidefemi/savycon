<?php namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\Access\User\BannerRequest;
use App\Models\Access\User\Banner;

/**
 * Class DashboardController
 * @package App\Http\Controllers\Backend
 */
class BannerController extends Controller {


	public function getBannerImages()
	{
		return view('backend.banner.new-banner-images');
	}

	public function SaveBannerImages(BannerRequest $bannerRequest)
	{
		$banner = new Banner();
		$file = $bannerRequest->file('image');
		$destinationPath = public_path().'/banner/';
		$filename = str_random(6).'_'.$file->getClientOriginalName();;
		$file->move($destinationPath, $filename);
		$banner->image = "/banner/". $filename;
		$banner->slug = uniqid();
		$banner->save();
		return redirect()->back()->withFlashSuccess("Created Successfully");
	}

	public function allBannerImages()
	{
		$banners = Banner::paginate(9);
		$count = 0;
		return view('backend.banner.all-banner-images', compact('banners', 'count'));
	}


	public function DeleteCategory($id)
	{
		Category::whereSlug($id)->delete();
		return redirect()->route('backend.all-cat')->withFlashMessage('Deleted Successfully');
	}

}