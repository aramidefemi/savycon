<?php namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Access\User\FeaturedAd;
use App\Models\Access\User\Freelancer;
use App\Models\Access\User\Product;
use App\Models\Access\User\User;

/**
 * Class DashboardController
 * @package App\Http\Controllers\Frontend
 */
class DashboardController extends Controller {

	/**
	 * @return mixed
	 */
	public function index()
	{
		$details = null;
		$id = auth()->user()->id;
		$featuredAd = FeaturedAd::where('to_show', 'home')->get();
		if(auth()->user()->user_type == 'freelance'){
			$category = Freelancer::whereUserId($id)->first()->category;
			//get all buyer with the same category
			$details = Product::where('category_name', $category)->paginate(9);
		}elseif(auth()->user()->user_type == 'buyer'){
			$category = Product::where('user_id', $id)->first();
			//get all freelance with the same category
			$details = Product::where('category_name', $category)->paginate(9);

		}else{

			$details = collect();
		}

		return view('frontend.user.dashboard', compact('details', 'featuredAd'))->withUser(auth()->user());
	}

	public function myPageFreeLance()
	{
		$id =  auth()->user()->id;
		$detail =  Freelancer::whereUserId($id)->first();
		$images = explode(',', $detail->img_url);
		$data = [
			'details' => $detail,
			'images' => $images
		];
		return view('frontend.user.mypage', compact('data'))->withUser(auth()->user());

	}
}
