<?php namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Frontend\User\SearchRequest;
use App\Http\Requests\Frontend\User\SubscribeRequest;
use App\Http\Requests\Frontend\User\SuggestionRequest;
use App\Http\Requests\Frontend\User\UploadRequest;
use App\Http\Requests\Request;
use App\Models\Access\User\Banner;
use App\Models\Access\User\Buyer;
use App\Models\Access\User\Category;
use App\Models\Access\User\FeaturedAd;
use App\Models\Access\User\Freelancer;
use App\Models\Access\User\Product;
use App\Models\Access\User\ProductPhotos;
use App\Models\Access\User\Record;
use App\Models\Access\User\Search;
use App\Models\Access\User\State;
use App\Models\Access\User\Local;
use App\Models\Access\User\Subscribe;
use App\Models\Access\User\Suggestion;
use App\Models\Access\User\User;

/**
 * Class FrontendController
 * @package App\Http\Controllers
 */
class FrontendController extends Controller {

	/**
	 * @return \Illuminate\View\View
	 */
	public function index()
	{
		$adverts = Product::orderBy('id', 'DESC')->paginate(4);
		$freelancers  = Freelancer::orderBy('id', 'DESC')->paginate(4);
		$featuredAd = FeaturedAd::where('to_show', 'home')->get();
		$banner = Banner::get()->last();
		$categories = State::get();
		return view('frontend.index', compact('adverts', 'freelancers', 'featuredAd', 'banner', 'categories'));
	}

	public function searchNews(SearchRequest $request)
	{
		$search = $request->q;
		$featuredAd = FeaturedAd::where('to_show', 'home')->get();
		$categories = State::get();
		$searchCategory = $request->category;
		if($search && strlen($search) > 1)
		{
			$adverts = Freelancer::where("title", 'like', '%' . $search . '%')->whereState($searchCategory)->paginate(10);
		}
		if($adverts->isEmpty()){
			    
				$saveQuery = new Search();
				$saveQuery->email = auth()->user() ? auth()->user()->email : 'Guest';
				$saveQuery->name =auth()->user() ? auth()->user()->name : 'Guest';
				$saveQuery->keyword = $search;
				$saveQuery->save();
		}
		return view("frontend.search-result", compact('adverts','featuredAd','categories', 'search'));
	}

	public function addAdvert(){
		//get user type
		$id = auth()->user()->id;
		$categories = Category::get();
		if(auth()->user()->user_type == 'freelance'){
			$category = Freelancer::whereUserId($id)->first()->category;
		}elseif(auth()->user()->user_type == 'buyer'){
			$category = Buyer::whereUserId($id)->first()->category;
		}else{
			$category  = '';
		}
		return view('frontend.advert.new-advert', compact('category', 'categories'));
	}

	public function GetLga($id)
	{
		$lgas = Local::orderBy('sub_state_name','ASC')->whereState_name($id)->get();
		return $lgas->toJson();
	}

	public function SaveAddAdvert(UploadRequest $uploadRequest)
	{
		$id = auth()->user()->id;
		if(auth()->user()->user_type == 'freelance'){
			$category = Freelancer::whereUserId($id)->first()->category;
		}elseif(auth()->user()->user_type == 'buyer'){
			$category = User::find(auth()->user()->id)->buyer->category;
		}else{
			$category = 'Super';
		}

		$product = new Product();
		$product->user_id = auth()->user()->id;
		$product->state = auth()->user()->state;
		$product->lga = auth()->user()->lga;
		$product->category_name =$category ;

		$product->title = $uploadRequest->title;
		$product->description = $uploadRequest->description;
		$product->price = $uploadRequest->price;
		$product->no_of_workers = $uploadRequest->no_of_worker;
		$product->no_of_gadget = $uploadRequest->no_of_gadget;
		$product->tag = $uploadRequest->tag;
		$product->address = $uploadRequest->address;
		
// 		return $product;
		$check = $product->save();

		if($check){
			foreach ($file = $uploadRequest->photos as $photo) {

				$filename = $photo->getClientOriginalName();
				$destination = "assets/Product/";
				$move = $photo->move($destination, $filename);
				if($move){
					ProductPhotos::create([
						'product_id' => $product->id,
						'filename' => $filename
					]);
				}
			}
			return redirect()->to('/dashboard')->withFlashMessage('Advert Created Successfully ');
		}

	}

	public function AuthUserAdvert()
	{
		$user_id = auth()->user()->id;
		$adverts = Product::whereUserId($user_id)->orderBy("id", 'DESC')->paginate(9);
		return view('frontend.advert.user-advert', compact('adverts'));
	}
	public function singleAdvert($id)
	{
		$product = Product::find($id);
		return view('frontend.advert.single-advert', compact('product'));
	}

	public function getSingleFreelance($id)
	{
		$freelance =  Freelancer::find($id);
		$images = explode(',',$freelance->img_url);
		return view('frontend.freelance.single-freelance', compact('freelance', 'images'));
	}
	public function allCategories()
	{
		$categories = Category::get();
		return view('frontend.category.all-category', compact('categories'));
	}
	public function BrowseCategory($id)
	{
		$browseProducts = Product::where('category_id', $id)->get();
		return view('frontend.category.browse-category', compact('browseProducts'));
	}

	public function getBuyer()
	{
		$states = State::get();
		$categories = Category::get();
		return view('frontend.auth.account.buyer', compact('states', 'categories'));
	}

	public function getFreelance()
	{
		$states = State::get();
		$categories = Category::get();
		return view('frontend.auth.account.freelance', compact('states', 'categories'));
	}

	public function getStarted()
	{
		return view('frontend.auth.account.start', compact('states', 'categories'));
	}
	public function Subscribe(SubscribeRequest $request)
	{
		$subscribe = new Subscribe();
		$subscribe->email = $request->email;
		$subscribe->save();
		return redirect()->back()->withFlashMessage('Thank you We will update you with Latest Update');

	}

	public function suggestion(SuggestionRequest $request)
	{
		$suggest = new Suggestion();
		$suggest->name = $request->name;
		$suggest->email = $request->email;
		$suggest->comment = $request->comment;
		$suggest->save();
		
		$message = "The mail message was sent with the following Details:\r\n Name:$request->name;\r\nEmail Addres: $request->email;\r\nComment : $request->comment;";

        $headers = "From: $request->email;";


        mail("admin@savycon.com", "New Comment Message", $message, $headers);
	    
	    	return redirect()->to('/')->withFlashMessage('Thanks for your contribution will Appreciate Your Opinion');
	}

	public function faq()
	{
		return view('frontend.faq');
	}

	public function about()
	{
		return view('frontend.about');
	}

	public function hiw()
	{
		return view('frontend.how-it-works');
	}

	public function contact()
	{
		return view('frontend.contact');
	}

	public function terms()
	{
		return view('frontend.terms');
	}

	public function privacy()
	{
		return view('frontend.privacy-policy');
	}

	public function shelters($solarCurrent, $solarVolt, $power, $batteryVolt, $temperature)
	{
		$record = new Record();
		$record->solar_current = $solarCurrent;
		$record->solar_volt = $solarVolt;
		$record->solar_temperature = $temperature;
		$record->solar_battery_volt = $batteryVolt;
		$record->solar_power = $power;
		$record->save();
	}


}