<?php

/**
 * Frontend Controllers
 */
get('/', 'FrontendController@index')->name('home');

get('/Lga/get/{id}', 'FrontendController@GetLga')->name('lga');
get('/single/ad/{id}', 'FrontendController@getSingleAd')->name('ad');
get('/single/freelance/{id}', 'FrontendController@getSingleFreelance')->name('freelancer-single');
get('get-started/register/', 'FrontendController@getStarted')->name('start');
get('get-started/register/buyer', 'FrontendController@getBuyer')->name('ad');
get('get-started/register/freelance', 'FrontendController@getFreelance')->name('ads');
post('subscribe-newsletter', 'FrontendController@Subscribe');
post('contact-us', 'FrontendController@suggestion');

get('frequently-ask-question', 'FrontendController@faq');
get('terms-of-use', 'FrontendController@terms');
get('how-it-works', 'FrontendController@hiw');
get('privacy-policy', 'FrontendController@privacy');
get('about', 'FrontendController@about');
get('contact-us', 'FrontendController@contact');

//search query method

get('search/results', 'FrontendController@searchNews');
/**
 * These frontend controllers require the user to be logged in
 */
$router->group(['middleware' => 'auth'], function ()
{
	get('dashboard', 'DashboardController@index')->name('frontend.dashboard');
	get('profile/edit', 'ProfileController@edit')->name('frontend.profile.edit');
	patch('profile/update', 'ProfileController@update')->name('frontend.profile.update');

	//	Custom Route for Application
	get('single/advert/{id}', 'FrontendController@singleAdvert');
	get('user/advert', 'FrontendController@AuthUserAdvert');

	get('profile/user', 'DashBoardController@myPageFreeLance');

	get('new-advert', 'FrontendController@addAdvert')->name('advert');
	post('new-advert', 'FrontendController@SaveAddAdvert')->name('save.advert');

});