<?php namespace App\Exceptions;

class GeneralException extends \Exception {}